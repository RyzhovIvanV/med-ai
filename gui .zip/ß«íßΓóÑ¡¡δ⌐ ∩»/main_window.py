import sys
from PyQt5 import uic
from PyQt5.QtWidgets import QApplication, QMainWindow
#импорт нужных библиотек

class MyWidget(QMainWindow):
    def __init__(self):
        super().__init__()
        self.start_window()
    # Просто надо

    def start_window(self):
        uic.loadUi('main_window.ui', self) #загрузка пользоватльского интерфейса
        #self.run_button.clicked.connect(self.clicked_action) #добавление действия на кнопку


    def clicked_action(self):
        pass

#Просто надо
if __name__ == '__main__':
    app = QApplication(sys.argv)
    ex = MyWidget()
    ex.show()
    sys.exit(app.exec_())
